import javax.sound.sampled.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
public class MyActionListener implements ActionListener {
    private ArrayList<File> songs;
    private  int songnumber;
    private Clip clip;
    private AudioInputStream audioInputStream;
    private JLabel label;
    private JMenuBar menuBar;
    private JFileChooser fileChooser;
    private JMenuItem LoadItem;
    private JMenuItem ExitItem;
    private int position;
    private boolean control =false;
    private File directory;
    private File[] files;
    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            if (e.getActionCommand().equals("PLAY")) {
                if (this.isControl()||!songs.isEmpty()) {
                    System.out.println("play");
                    this.changeClip();
                    this.changeName();
                    clip.open(this.audioInputStream);
                    clip.setFramePosition(getPosition());
                    clip.start();
                    this.setControl(false);
                }
            }
            if (e.getActionCommand().equals("STOP")) {
                System.out.println("Stop");
                if (this.clip != null) {
                    setPosition(clip.getFramePosition());
                    clip.stop();
                    this.setControl(true);
                }
            }
            if (e.getActionCommand().equals("PREVIOUS")) {
                if (this.clip != null) {
                    clip.stop();
                    if (songnumber > 0) {
                        this.setSongnumber(songnumber - 1);
                    } else {
                        this.setSongnumber(this.getSongs().size() - 1);
                    }
                    this.changeClip();
                    clip.open(this.audioInputStream);
                    this.changeName();
                    this.setControl(true);
                }
            }
            if (e.getActionCommand().equals("NEXT")) {
                if (this.clip != null) {
                    clip.stop();
                    if (this.getSongnumber() < this.songs.size() - 1) {
                        this.setSongnumber(this.getSongnumber() + 1);
                    } else {
                        this.setSongnumber(0);
                    }
                    this.changeClip();
                    this.changeName();
                    clip.open(this.audioInputStream);
                    this.setControl(true);
                }

            }
            if (e.getActionCommand().equals("REPLAY")) {
                if (this.clip != null) {
                    clip.stop();
                    clip.setFramePosition(0);
                    clip.start();
                    this.setControl(false);
                } else {
                    this.setControl(true);
                }
            }
            if(e.getSource()==LoadItem){
                addFilechooser();
                int response=fileChooser.showSaveDialog(null);
                if (response == JFileChooser.APPROVE_OPTION){
                    File file=new File(fileChooser.getSelectedFile().getAbsolutePath());
                    if (!songs.contains(file)){
                        songs.add(file);
                        Files.move(file.toPath(),directory.toPath(), StandardCopyOption.ATOMIC_MOVE);
                    }
                }
            }
            if (e.getSource()==ExitItem){
                System.exit(0);
            }
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException ex) {
            throw new RuntimeException(ex);
        }
    }
    public ArrayList<File> getSongs() {
        return songs;
    }

    public void setSongs(ArrayList<File> songs) {
        this.songs = songs;
    }

    public int getSongnumber() {
        return songnumber;
    }

    public void setSongnumber(int songnumber) {
        this.songnumber = songnumber;
    }

    /*
    changeClip lets me change clip
    */
    private void changeClip() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
        this.audioInputStream = AudioSystem.getAudioInputStream(songs.get(this.getSongnumber()));
        this.clip = AudioSystem.getClip();
    }

    private void changeName(){
        label.setText(songs.get(songnumber).getName());
    }
    /*
    setLabel lets me create label to later list song name
    */
    public void setLabel() {
        label =new JLabel();
        if (songs.isEmpty()){
           label.setText("Add Songs");
        }else {
            label.setText(songs.get(songnumber).getName());
        }
        label.setFont(new Font("Comic Sans", Font.BOLD, 30));
        label.setVerticalAlignment(JLabel.CENTER);
        label.setHorizontalAlignment(JLabel.CENTER);
        label.setBounds(150,100,300,100);
    }

    public JLabel getLabel() {
        return label;
    }
    public JMenuBar getMenuBar() {
        return menuBar;
    }
     /*
     setMenuBar lets me create menubar to later use to navigate user to load or exit
     */
    public void setMenuBar() {
        menuBar=new JMenuBar();
        JMenu jMenu = new JMenu("File");
        menuBar.add(jMenu);
        LoadItem =new JMenuItem("Load");
        ExitItem =new JMenuItem("Exit");
        LoadItem.addActionListener(this);
        ExitItem.addActionListener(this);
        jMenu.add(LoadItem);
        jMenu.add(ExitItem);
        menuBar.add(jMenu);
        menuBar.setBounds(0,0,30,20);
    }
    /*
    loadFile lets me load files from directory
    */
     void loadFile() {
        songs = new ArrayList<>();
        directory = new File("music");
        files = directory.listFiles();
        if (files != null) {
            songs.addAll(Arrays.asList(files));
        }
    }
    public void addFilechooser(){
        fileChooser =new JFileChooser();
    }

    public boolean isControl() {
        return control;
    }
    public void setControl(boolean control) {
        this.control = control;
    }
    public JFileChooser getFileChooser() {
        return fileChooser;
    }
    public int getPosition() {
        return position;
    }
    public void setPosition(int position) {
        this.position = position;
    }
}