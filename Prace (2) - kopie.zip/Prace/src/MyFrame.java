import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.util.ArrayList;

public class MyFrame extends JFrame {

    MyActionListener listener;
    JFrame frame;
    JButton buttonPlay, buttonStop, buttonPrevious, buttonNext,buttonReplay;
    JButton[] functionsButtons = new JButton[5];

    JPanel panel;
    ArrayList<File> songs;

    public MyFrame() {
        frame = new JFrame("Music Player");
        frame.setSize(620, 300);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setLayout(null);
        listener = new MyActionListener();
        listener.loadFile();
        setSongs(listener.getSongs());
        ImageIcon icon = new ImageIcon("spotify.jpg");
        frame.setIconImage(icon.getImage());
        addButtons();
        addPanel();
        frame.add(panel);
        listener.setLabel();
        listener.setMenuBar();
        frame.add(listener.getLabel());
        frame.add(listener.getMenuBar());
        frame.setVisible(true);
    }

    /*
    * addButtons lets me create Fuction Buttons and add them to array and assigned them fuctions
    */
    private void addButtons() {
        buttonPlay = new JButton("PLAY");
        buttonStop = new JButton("STOP");
        buttonPrevious = new JButton("PREVIOUS");
        buttonNext = new JButton("NEXT");
        buttonReplay =new JButton("REPLAY");
        functionsButtons[0] = buttonPlay;
        functionsButtons[1] = buttonStop;
        functionsButtons[2] = buttonNext;
        functionsButtons[3] = buttonPrevious;
        functionsButtons[4] =buttonReplay;
        for (JButton functionsButton : functionsButtons) {
            functionsButton.setFocusable(false);
            functionsButton.setFont(new Font("Comic Sans", Font.BOLD, 15));
            functionsButton.addActionListener(listener);
        }
    }
    /*
    * addPanel lets me create panel where I put array of buttons and automaticly repositons them to accordings size
    */
    private void addPanel() {
        panel = new JPanel();
        panel.setBounds(0, 165, 620, 100);
        panel.setBackground(Color.GRAY);
        panel.setLayout(new GridLayout(1, 1, 0, 0));
        for (JButton functionsButton : functionsButtons) {
            panel.add(functionsButton);
        }
    }

    public ArrayList<File> getSongs() {
        return songs;
    }

    public void setSongs(ArrayList<File> songs) {
        this.songs = songs;
    }
}
